module Cryptography {
	requires java.desktop;
}